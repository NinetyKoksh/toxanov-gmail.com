﻿using System;
using System.Collections.Generic;

namespace SingletonUniversity
{
    public class Database2
    {

        public List<Student> Students;

        public List<Subject> Subjects;
        public List<Teacher> Teachers;
        public Database2()
        {
        }
    }
}
