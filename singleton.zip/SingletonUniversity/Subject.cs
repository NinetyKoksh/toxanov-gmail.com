﻿using System;
using System.Collections.Generic;

namespace SingletonUniversity
{
    public class Subject
    {
        public string Name {get; set;}
        public Teacher Teacher { get; set; }
        public List <string> Teacher2 { get; set; }
    }
}
