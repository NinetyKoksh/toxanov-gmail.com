﻿using System;
using System.Collections.Generic;
namespace SingletonUniversity
{
    public class Human
    {
        public string Name{ get; set; }
    }
}
