﻿using System;
using System.Collections.Generic;

namespace SingletonUniversity
{
    
    
    public class Student: Human
        
    {
        public List<string> Subjects2 { get; set; }

        public List<Subject> Subjects { get; set; }
        
    }
}
